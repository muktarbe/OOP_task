import java.util.Arrays;

public class MyClass {
    String  mane;
    String surnames;
    int age;
    String [] lessons;
    String dishes;

    public MyClass(String mane, String surnames, int age, String[] lessons, String dishes) {
        this.mane = mane;
        this.surnames = surnames;
        this.age = age;
        this.lessons = lessons;
        this.dishes = dishes;
    }

    public MyClass() {
        this.mane = mane;
        this.surnames = surnames;
        this.age = age;
        this.lessons = lessons;
        this.dishes = dishes;
    }

    @Override
    public String toString() {
        return "MyClass \n" +
                "  mane = " + mane + "\n"+
                ", surnames = " + surnames + "\n"+
                ", age = " + age +"\n"+
                ", lessons = " + Arrays.toString(lessons) +"\n"+
                ", dishes = " + dishes + "\n";
    }
}
