// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {


        //LMS 1 ЗАДАЧА
        Triangle triangle = new Triangle(5,5,5);
        triangle.area(triangle);

        //LMS 2 ЗАДАЧА

        MyClass myClass = new MyClass("Muktarbek "," Elebesov ",17,new String[]{"aa","bb"},"asdfgh");
        MyClass myClass2 = new MyClass();
        myClass2.mane = "Muktarbek";
        myClass2.surnames = "Elebesov";
        myClass2.age = 17;
        myClass2.lessons = new String[]{"as","dfg"};
        myClass2.dishes = "sdf";

        System.out.println(myClass);
        System.out.println("=================================\n");
        System.out.println(myClass2);


    }
}